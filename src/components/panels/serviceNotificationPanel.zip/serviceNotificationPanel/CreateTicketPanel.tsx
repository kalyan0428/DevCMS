import { ReactComponent as CrossLogo } from '../../../assets/img/serviceNotificationPanel/crossLogo.svg';

const CreateTicketPanel = () => {

  return (
    <section>
     Create Ticket
    
    </section>
  );
};

export default CreateTicketPanel;
