export const DummyData: any = [];

for (let i = 0; i < 20; i++) {
  DummyData.push({
    text1: "AL67154",
    text2: "RRP-TCP",
    date: "21/09/2021",
    time: "20:11:10",
    text3: "Fault in Digital Voice Announcement",
    text5: "TSNSW-RS-D-D104",
  });
}
