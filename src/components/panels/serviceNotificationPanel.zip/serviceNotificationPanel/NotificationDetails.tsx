import { FocusZone, FocusZoneDirection } from "@fluentui/react-focus";
import React from "react";
import { Cabin } from "../../trains";
import {CabinSvg, classNames, EditpenSvg, RoundButton} from "./"
import { Modal } from "@fluentui/react";
import { connect } from "react-redux";
import { Dispatch, bindActionCreators } from "redux";
import {
  fetchServiceNotifications,
  setSelectedTicket,
} from "../../../store/actions/service-notification.actions";
import { CSVLink, CSVDownload } from "react-csv";
import { Link } from "react-router-dom";

import { TrainSvg, CrossLogo, ExportLogo } from "./";
import _ from "lodash";

interface NotificationDetails {
  selectedTicket?: any;
  editPanelHandler: () => void;
  closeNotificationDetails: () => void;
}
const Description=({
  selectedTicket,
  editPanelHandler,
  closeNotificationDetails,
}: NotificationDetails)=>{

    const {
      
    card,
    service_data_class,
    panelHeaderContainer,
    notificationcontainer,
    LongText,
    cardsParent,
    service_links,
    description_body,
    filled_button,
    service_column_class,
    DescriptionHeader,
    DescrptionParent,
    grid_cell,
    grid_row,
    borderRigth,
    subText,
    service_links_first,
    actions,
    actionsRow,
    ticketDetails,
    ticketDetailsName,
    buttonContainer,
    deleteButton,
    headerTitle,
    headerSubTitle,
    bottomLinks,
    link,
    deletePopUpContainer,
    bottomLinks2,
    deleteButtons,
    renderTextPopUpStyle,
    attachment,
       
      } = classNames;

      const [deletePopUp, setDeletePopUp] = React.useState<boolean>(false);

  const [readMore, setReadMore] = React.useState<boolean>(false);

  const [viewMore, setViewMore] = React.useState<boolean>(false);


  const [textPopUp, setTextPopUp] = React.useState<boolean>(false);

  const renderNotificationDetails = () => {
    return (
      <div className={ticketDetails}>
        <div className={ticketDetailsName}>Service Notification Deatails</div>
        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`ms-Grid-col ms-sm6 ${borderRigth}`}>
              <div className={grid_cell}>
                <small>Service Notification No.</small>
                <h3>61453287635</h3>
              </div>
            </div>

            <div className={`ms-Grid-col ms-sm6`}>
              <div className={grid_cell}>
                <small>Service Order No.</small>
                <h3>614523689654</h3>
              </div>
            </div>
          </div>
        </div>
        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`ms-Grid-col ms-sm6 ${borderRigth}`}>
              <div className={grid_cell}>
                <small>Notification Type</small>
                <h3>{selectedTicket.notificaiton_type}</h3>
              </div>
            </div>

            <div className={`ms-Grid-col ms-sm6`}>
              <div className={grid_cell}>
                <small>Notification Date & Time</small>
                <h3>22/12/2020 | 10:04 AM</h3>
              </div>
            </div>
          </div>
        </div>

        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`ms-Grid-col ms-sm6 ${borderRigth}`}>
              <div className={grid_cell}>
                <small>Location</small>
                <h3>Orange - 2800</h3>
              </div>
            </div>
            <div className={`ms-Grid-col ms-sm6`}>
              <div className={grid_cell}>
                <small>Effect</small>
                <h3>No Effect</h3>
              </div>
            </div>
          </div>
        </div>
        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`ms-Grid-col ms-sm6 ${borderRigth}`}>
              <div className={grid_cell}>
                <small>Reported By</small>
                <h3>{selectedTicket.raised_by}</h3>
              </div>
            </div>
            <div className={`ms-Grid-col ms-sm6`}>
              <div className={grid_cell}>
                <small>Driver</small>
                <h3>John</h3>
              </div>
            </div>
          </div>
        </div>
        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`${grid_cell}`}>
              <small>Notification Description</small>
              <p>{selectedTicket.notification_description}</p>
            </div>
          </div>
        </div>
      </div>
    );
  };



  const renderTicketDetails = () => {
    return (
      <div className={ticketDetails}>
        <div className={ticketDetailsName}>Ticket Details</div>
        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`ms-Grid-col ms-sm6 ${borderRigth}`}>
              <div className={grid_cell}>
                <small>Notification Type</small>
                <h3>{selectedTicket.notificaiton_type}</h3>
              </div>
            </div>

            <div className={`ms-Grid-col ms-sm6`}>
              <div className={grid_cell}>
                <small>Notification Date & Time</small>
                <h3>22/12/2020 | 10:04 AM</h3>
              </div>
            </div>
          </div>
        </div>

        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`ms-Grid-col ms-sm6 ${borderRigth}`}>
              <div className={grid_cell}>
                <small>Malfunction Start Date & Time</small>
                <h3>{selectedTicket.malfunctionstart_datetime}</h3>
              </div>
            </div>
            <div className={`ms-Grid-col ms-sm6`}>
              <div className={grid_cell}>
                <small>Malfunction End Date & Time</small>
                <h3>{selectedTicket.create_datetime}</h3>
              </div>
            </div>
          </div>
        </div>
        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`ms-Grid-col ms-sm6 ${borderRigth}`}>
              <div className={grid_cell}>
                <small>Reported By</small>
                <h3>{selectedTicket.raised_by}</h3>
              </div>
            </div>
            <div className={`ms-Grid-col ms-sm6`}>
              <div className={grid_cell}>
                <small>Driver</small>
                <h3>John</h3>
              </div>
            </div>
          </div>
        </div>
        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`${grid_cell}`}>
              <small>Location</small>
              <p>Orange</p>
            </div>
          </div>
        </div>
        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`${grid_cell}`}>
              <small>Notification Description</small>
              <p>{selectedTicket.notification_description}</p>
            </div>
          </div>
        </div>
      </div>
    );
  };


  const renderViewMoreNotificationDetails = () => {
    return (<>
      <br/>
      <div className={ticketDetails}>
        <div className={ticketDetailsName}>Equipment & Object Details</div>
        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`ms-Grid-col ms-sm6 ${borderRigth}`}>
              <div className={grid_cell}>
                <small>Functional Location</small>
                <h3>{selectedTicket.functional_location}</h3>
              </div>
            </div>

            <div className={`ms-Grid-col ms-sm6`}>
              <div className={grid_cell}>
                <small>Functional Location Description</small>
                <h3>D5-Intercity Short Unit</h3>
              </div>
            </div>
          </div>
        </div>

        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`ms-Grid-col ms-sm6 ${borderRigth}`}>
              <div className={grid_cell}>
                <small>Equipment</small>
                <h3>DDA9305</h3>
              </div>
            </div>
            <div className={`ms-Grid-col ms-sm6`}>
              <div className={grid_cell}>
                <small>Equipment Description</small>
                <h3>DDA9305 - Intercity A-CAR</h3>
              </div>
            </div>
          </div>
        </div>
        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`${grid_cell}`}>
              <small>Code Group - Object Part Description</small>
              <p>Compressed Air Supply</p>
            </div>
          </div>
        </div>
      </div>
      <br/>      
      <div className={ticketDetails}>
        <div className={ticketDetailsName}>Other Key Dates</div>
        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`ms-Grid-col ms-sm6 ${borderRigth}`}>
              <div className={grid_cell}>
                <small>Created On Date & Time</small>
                <h3>05/07/2020 | 11:04 AM</h3>
              </div>
            </div>

            <div className={`ms-Grid-col ms-sm6`}>
              <div className={grid_cell}>
                <small>Changed On Date & Time</small>
                <h3>05/07/2020 | 11:04 AM</h3>
              </div>
            </div>
          </div>
        </div>
      </div>

      <br/>
      <div className={ticketDetails}>
        <div className={ticketDetailsName}>Minimum Operating Standard & Waiver Details</div>
        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`${grid_cell}`}>
              <small>MOS Reference No.</small>
              <p>RRP_MOS_54</p>
            </div>
          </div>
        </div>
        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`${grid_cell}`}>
              <small>Constraints</small>
              <p>ISOC, SPD80</p>
            </div>
          </div>
        </div>
        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`${grid_cell}`}>
              <small>Waiver Reference No.</small>
              <p>We001</p>
            </div>
          </div>
        </div>
        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`${grid_cell}`}>
              <small>Waived Constraints</small>
              <p>SPD80</p>
            </div>
          </div>
        </div>
        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`${grid_cell}`}>
              <small>Waiver Validity Period</small>
              <p>04/07/2021 - 05/07/2021</p>
            </div>
          </div>
        </div>
      </div>
      <br/>
      <div className={bottomLinks}>
        <a className={link}></a>
        <a
          className={`${link} cursor`}
          onClick={(e) => {
            e.preventDefault()
            setTextPopUp(true)}}
        >
          Coding Code Long Text
        </a>
      </div>
    </>)
  }
  const renderNotficationUnitDetails = () => {
    return (<>
      <br/>
      <div className={ticketDetails}>
        <div className={ticketDetailsName}>Unit Details</div>
        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`ms-Grid-col ms-sm6 ${borderRigth}`}>
              <div className={grid_cell}>
                <small>Unit</small>
                <h3>D104</h3>
              </div>
            </div>

            <div className={`ms-Grid-col ms-sm6`}>
              <div className={grid_cell}>
                <small>Car</small>
                <h3>RDA2301</h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>);
  };

  const renderViewMore = () => {
    return (<>
          <br/>
      <div className={bottomLinks}>
            <a
              className={`${link} cursor`}
              onClick={(e) => {
                e.preventDefault();
                setViewMore(!viewMore)}}
            >
              {!viewMore ? "View More" : "View Less"}
            </a>
            <a className={`${link} cursor`} onClick={(e)=> e.preventDefault()}>
              For More Details Go to Unit Mainteance Planning
            </a>
          </div>
    </>)
  }
  const renderActiveConstraints = () => {
    return (<>
    <br />
      <div className={ticketDetails}>
        <div className={ticketDetailsName}>Active Constraints</div>
        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`ms-Grid-col ms-sm6 ${borderRigth}`}>
              <div className={grid_cell}>
                <small>Active Constraints</small>
                <h3>ISOC</h3>
              </div>
            </div>

            <div className={`ms-Grid-col ms-sm6`}>
              <div className={grid_cell}>
                <small>Complete By</small>
                <h3>14/08/2021</h3>
              </div>
            </div>
          </div>
        </div>
      </div>
      {!viewMore ? renderViewMore(): false} 
    </>);
  };

  const renderUnitDetails = () => {
    return (<>
      <br/>
      <div className={ticketDetails}>
        <div className={ticketDetailsName}>Unit Details</div>
        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`ms-Grid-col ms-sm6 ${borderRigth}`}>
              <div className={grid_cell}>
                <small>Unit</small>
                <h3>D104</h3>
              </div>
            </div>

            <div className={`ms-Grid-col ms-sm6`}>
              <div className={grid_cell}>
                <small>Car</small>
                <h3>RDA2301</h3>
              </div>
            </div>
          </div>
        </div>

        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`${grid_cell}`}>
              <small>Functional Location Description</small>
              <p>D4 - Intercity Short Unit</p>
            </div>
          </div>
        </div>
        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`${grid_cell}`}>
              <small>Equipment Description</small>
              <p>DDA9305 - Intercity A-CAR</p>
            </div>
          </div>
        </div>
      </div>
    </>);
  };

  const renderNotificationLongText = () => {
    return (<>
    <br />
      <div className={ticketDetails}>
        <div className={ticketDetailsName}>Notification Long Text</div>
        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`${grid_cell}`}>
              <small>CMS User Notes:</small>
              <p
                style={
                  !readMore
                    ? {
                        maxHeight: "450px",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                      }
                    : {}
                }
              >
<p>Enter additional notes here</p>
<p>Enter additional notes here</p>
<p>Enter additional notes here</p>
<p>Enter additional notes here</p>
<p>Enter additional notes here</p>
<p>Enter additional notes here</p>
<p>Enter additional notes here</p>
<p>Enter additional notes here</p>
<p>Enter additional notes here</p>
<p>Enter additional notes here</p>
<p>Enter additional notes here</p>
<p>Enter additional notes here</p>
<p>Enter additional notes here</p>
<p>Enter additional notes here</p>
<p>Enter additional notes here</p>


<p>Enter additional notes here</p>
<p>Enter additional notes here</p>
              </p>
            </div>
          </div>
          <div className={bottomLinks}>
            { selectedTicket.status === "DRAFT" ? (  <>          
            <div>
              <a
                className={`${link} cursor`}
                onClick={(e) => {
                  e.preventDefault();
                  setReadMore(!readMore)}}
              >
                {!readMore ? "Read More" : "Read Less"}
              </a>
              <a className={`${link} cursor`} onClick={(e) => {
                e.preventDefault();
                setTextPopUp(true)
                }}>
                Open in New Tab
              </a>
            </div>
            <a className={`${link} cursor`} onClick={(e) => {
                e.preventDefault();
                }}>
                Go to SAP
              </a></>): (<>          
              <a
                className={`${link} cursor`}
                onClick={(e) => {
                  e.preventDefault();
                  setReadMore(!readMore)}}
              >
                {!readMore ? "Read More" : "Read Less"}
              </a>
              <a className={`${link} cursor`} onClick={(e) => {
                e.preventDefault();
                setTextPopUp(true)
                }}>
                Open in New Tab
              </a>
            </>)}

          </div>
        </div>
      </div>
      </>);
  };

  const renderCodeGroupDetails = () => {
    return (<>
    <br/>
      <div className={ticketDetails}>
        <div className={ticketDetailsName}>Code Group Details</div>
        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`ms-Grid-col ms-sm6 ${borderRigth}`}>
              <div className={grid_cell}>
                <small>Code Group</small>
                <h3>{selectedTicket.code_group}</h3>
              </div>
            </div>

            <div className={`ms-Grid-col ms-sm6`}>
              <div className={grid_cell}>
                <small>Coding Code</small>
                <h3>0010</h3>
              </div>
            </div>
          </div>
        </div>

        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`${grid_cell}`}>
              <small>Coding Group Description</small>
              <p>{selectedTicket.coding_group_description}</p>
            </div>
          </div>
        </div>
        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`${grid_cell}`}>
              <small>Coding Code Description</small>
              <p>{selectedTicket.coding_code_description}</p>
            </div>
            <div className={bottomLinks}>
              <a className={link}></a>
              <a
                className={`${link} cursor`}
                onClick={(e) => {
                  e.preventDefault()
                  setTextPopUp(true)}}
              >
                Coding Code Long Text
              </a>
            </div>
          </div>
        </div>
      </div>
      </>);
  };

  const renderEffect = () => {
    return <>
      <br/>
      <div className={ticketDetails}>
        <div className={ticketDetailsName}>Effect</div>
        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`${grid_cell}`}>
              <small>Effect</small>
              <p>No effect</p>
            </div>
          </div>
        </div>
      </div>
    </>;
  };

  const renderConstraints = () => {
    return (<>
      <br/>
      <div className={ticketDetails}>
        <div className={ticketDetailsName}>Constraints</div>
        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`ms-Grid-col ms-sm6 ${borderRigth}`}>
              <div className={grid_cell}>
                <small>MOS Ref No.</small>
                <h3>RRP_MOS-54</h3>
              </div>
            </div>

            <div className={`ms-Grid-col ms-sm6`}>
              <div className={grid_cell}>
                <small>Completed By</small>
                <h3>05/10/2021</h3>
              </div>
            </div>
          </div>
        </div>

        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`${grid_cell}`}>
              <small>Constraints</small>
              <p>ISOC</p>
            </div>
          </div>
        </div>
      </div>
    </>);
  };

  const renderObjectPartDetails = () => {
    return (<>
    <br/>
      <div className={ticketDetails}>
        <div className={ticketDetailsName}>Object Part Details</div>
        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`ms-Grid-col ms-sm6 ${borderRigth}`}>
              <div className={grid_cell}>
                <small>Object part - Code Group</small>
                <h3>DMU-CAS</h3>
              </div>
            </div>

            <div className={`ms-Grid-col ms-sm6`}>
              <div className={grid_cell}>
                <small>Part of Object</small>
                <h3>{selectedTicket.part_of_object}</h3>
              </div>
            </div>
          </div>
        </div>

        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`${grid_cell}`}>
              <small>Object part - Coding Group Description</small>
              <p>Compresses Air Supply</p>
            </div>
          </div>
        </div>
        <div className={service_data_class}>
          <div className={`ms-Grid-row ${grid_row}`}>
            <div className={`${grid_cell}`}>
              <small>Part of Object Description</small>
              <p>Compresses Air Supply</p>
            </div>
          </div>
        </div>
      </div>
    </>);
  };

  const renderDeletePopUp = () => {
    return (
      <Modal isOpen={deletePopUp}>
        <div className={deletePopUpContainer}>
          <p>Are you sure you want to delete?</p>
          <div className={deleteButtons}>
            <RoundButton text="Delete" />
            <div>&nbsp;&nbsp;</div>
            <RoundButton onClick={() => setDeletePopUp(false)} text="Cancel" />
          </div>
        </div>
      </Modal>
    );
  };

  const renderTextPopUp = () => {
    return (
      <Modal isOpen={textPopUp}>
        <div className={renderTextPopUpStyle}>
        <p>Enter additional notes here</p>
<p>Enter additional notes here</p>
<p>Enter additional notes here</p>
<p>Enter additional notes here</p>
<p>Enter additional notes here</p>
<p>Enter additional notes here</p>
<p>Enter additional notes here</p>
<p>Enter additional notes here</p>
<p>Enter additional notes here</p>
<p>Enter additional notes here</p>
<p>Enter additional notes here</p>
<p>Enter additional notes here</p>
<p>Enter additional notes here</p>
<p>Enter additional notes here</p>
<p>Enter additional notes here</p>


<p>Enter additional notes here 16</p>
<p>Enter additional notes here 17</p>
          <RoundButton onClick={() => setTextPopUp(false)} text="Close" />
        </div>
      </Modal>
    );
  };

  let screenHeight = window.innerHeight - 60

  if(selectedTicket.status === "DRAFT"){
    screenHeight -= 15;
  }

return(
<div className={description_body} style={{height: selectedTicket.status === "DRAFT" ? screenHeight + 15: screenHeight}}>
      {renderDeletePopUp()}
      <div className={notificationcontainer}  style={{height: selectedTicket.status === "DRAFT" ? screenHeight + 15: screenHeight}}>
        <div className={DescriptionHeader}>
          <div className={headerTitle}>
          <CrossLogo className="cursor" onClick={closeNotificationDetails} /> 
          &nbsp;&nbsp;
            <h3>
            {selectedTicket.status === "DRAFT" ? "Notification" : "Ticket"} Details | ID: {selectedTicket.defect_id} <br />
              <div className={headerSubTitle}>
                <TrainSvg /> WCW-4-2 | {selectedTicket.type} |{" "}
                {selectedTicket.status} | {selectedTicket.priority}
              </div>
            </h3>
          </div>
          {selectedTicket.status === "DRAFT" ? (
            <EditpenSvg className="cursor" onClick={editPanelHandler} />
          ) : (
            <CSVLink
              data={[
                Object.keys(selectedTicket),
                Object.values(selectedTicket),
              ]}
              filename={`${selectedTicket.defect_id}.csv`}
            >
              <ExportLogo className="cursor" />
            </CSVLink>
          )}
        </div>

        <div
          className={DescrptionParent }
          style={{height: screenHeight - 70}}
        >
          <div style={{padding: "10px"}}>
          <br />

          { selectedTicket.status === "DRAFT"  ?
            renderNotificationDetails()
            :renderTicketDetails()
          }

          
          { selectedTicket.status === "DRAFT" ? renderNotficationUnitDetails(): renderUnitDetails()}

          { selectedTicket.status === "DRAFT" ? renderActiveConstraints(): false}

          { viewMore ? renderViewMoreNotificationDetails() : false}
          {viewMore ? renderViewMore(): false} 


          {renderNotificationLongText()}
          

          { selectedTicket.status === "DRAFT" ? false: renderEffect()}


          { selectedTicket.status === "DRAFT" ? false: renderCodeGroupDetails()}


          { selectedTicket.status === "DRAFT" ? false: renderConstraints()}


          { selectedTicket.status === "DRAFT" ? false: renderObjectPartDetails()}


          {renderTextPopUp()}
          <br />

          <h4>Attachments</h4>
          <div
            style={{ display: "flex", overflowX: "scroll" }}
          >
            {_.map([1, 2, 3, 4, 5, 6, 7, 8], (value, index) => (
              <div
                className={attachment}
                style={index === 0 ? {} : { marginLeft: "20px" }}
                color="teal"
              >
                <CabinSvg />
              </div>
            ))}
          </div>
          <br />

          <br />
          <div className={bottomLinks2}>
            <div>
              <Link to="/Diagnostics" className={link}>
                Diagnosis Guide
              </Link>

              <a href="" className={link} onClick={(e) => e.preventDefault()}>
                Open HMI
              </a>
            </div>

            <Link to="/UnitOverview" className={link}>
              Unit Overview
            </Link>
          </div>
          <br />  
          </div>
          {selectedTicket.status === "DRAFT" ? (
            <div className={buttonContainer}>
              <RoundButton
                onClick={() => setDeletePopUp(true)}
                className={deleteButton}
                text="Delete"
              />
              <RoundButton text="Link to Current Defect" />
              <button type="submit" className={`${filled_button} cursor`}>
                submit
              </button>
            </div>
          ) : (
            false
          )}
        </div>
      </div>

    </div>


)

}

function mapStateToProps(state: any): any {
  return {
    selectedTicket: state.serviceNotificationReducer.selectedTicket,
  };
}

function mapDispatchToProps(dispatch: Dispatch<any>): any {
  return {
    ...bindActionCreators({}, dispatch),
  };
}

const DescriptionComponent = connect(
  mapStateToProps,
  mapDispatchToProps
)(Description);

export default DescriptionComponent;
