import { useState, useEffect } from "react";
import { FocusZone, FocusZoneDirection } from "@fluentui/react/lib/FocusZone";
import { List } from "@fluentui/react/lib/List";
import { Text } from "@fluentui/react/lib/Text";
import { Stack } from "@fluentui/react/lib/Stack";
import { Pivot, PivotItem, SearchBox, Icon, Spinner, SpinnerSize } from "@fluentui/react";
import { connect } from 'react-redux';
import { Dispatch, bindActionCreators } from 'redux';
import { fetchServiceNotifications, setSelectedTicket } from '../../../store/actions/service-notification.actions'
import { Ticket } from '../../../models/service-notification.model'
import {
  classNames,
  CloseLeftarrow,
  UpArrow,
  RoundButton,
  SearchIcon,
  TrainSvg,
  DummyData,
} from "./";
import _ from "lodash";
import moment, {Moment} from 'moment';

interface MaximizedPanelProps {
  servicePanelHandler: () => void;
  servicePaneldata: (item:any) => void;
  fetchServiceNotifications: () => void;
  setSelectedTicket: (item?: any) => void;
  selectedTicket: Ticket;
  notifications: Array<Ticket>;
  notificationsValues: Array<any>,
  fetching: boolean
}



const MaximizedPanel = (props : MaximizedPanelProps) => {
  const {
    maximizedPanel,
    maximizedPanelOpen,
    maximizedPanelClose,
    leftArrowClose,
    arrowRotation,
    panelHeaderContainer,
    searchIcon,
    cardsParent,
    card,
    cardHeaderContainer,
    cardBody,
    cardBottom,
    labelWidth,
    labelWidth2,
    linkIsSelected,
    selectedCard,
    noData,
    focusZone,
    searchBox,
    cancelIcon
  } = classNames;
  const [anim, setAnim] = useState(maximizedPanelOpen);
  const [unsubmitted, setUnsubmitted] = useState<Array<Ticket>>([]);
  const [recent, setRecent] = useState<Array<Ticket>>([]);
  const [selected, setSelected] = useState<any>("");
  const [showSearch, setShowSearch] = useState<boolean>(false);
  // const [searchWord, setSearchWord] = useState<string | undefined>('');
  const [searchValue, setSearchValue] = useState<string | undefined>('');
  const [loading, setLoading] = useState<boolean>(true);
  
  const animHandler = () => {
    setAnim(maximizedPanelClose);
    setTimeout(() => props.servicePanelHandler(), 0);
    setSelected("");
    props.setSelectedTicket({}); 
  };

  const onRenderCell = (
    item: Ticket | undefined,
    index: number | undefined
  ): JSX.Element => {

    const onTicketClick = ()=>{
      props.servicePaneldata(item)
      const selectedItemData:any = _.find(props.notificationsValues, data => data.defect_id === item?.defect_id)
      props.setSelectedTicket(selectedItemData); 
      setRecent([...recent]);
      setUnsubmitted([...unsubmitted])
    }

    return (
      // <div className={`${card} ${(selected && (item?.defect_id === selected.defect_id)) ? selectedCard: ""}`} onClick={()=>{
      <div className={(item?.defect_id === props.selectedTicket.defect_id? [card, selectedCard].join(" "): card)} onClick={onTicketClick}>
        <div className={cardHeaderContainer}>
          <ul>
            <div>
              {/* <Stack>
                <Text nowrap={true} className={labelWidth}> */}
                  {item?.defect_id}
                {/* </Text>
              </Stack> */}
            </div>
            {/* <li>
              <Stack>
                <Text nowrap className={labelWidth}>
                  {item?.code_group}
                </Text>
              </Stack>
            </li> */}
          </ul>
          <ul>
            <li>{item?.date}</li>
            <li>{item?.time}</li>
          </ul>
        </div>
        <div className={cardBody}>{item?.notification_description}</div>
        <div className={cardBottom}>
          <div>
            <TrainSvg />
            <div>
              <Stack>
                <Text nowrap className={labelWidth2}>
                  {item?.functional_location}
                </Text>
              </Stack>
            </div>
          </div>
          <ul>
            <li>{item?.status}</li>
            <li>{item?.priority}</li>
          </ul>
        </div>
      </div>
    );
  };

  useEffect(() => {
    props.fetchServiceNotifications()
  }, [])

  useEffect(() => {
    setRecent([...recent])
    setUnsubmitted([...unsubmitted])
  }, [props.selectedTicket])

  useEffect(() => {
    setLoading(true);
    const unsubmittedTicket:Array<Ticket> = [];
    const recentTicket:Array<Ticket> = [];
    _.forEach(props.notifications, (ticket:Ticket, index:number) => {
      const date:Moment = moment(_.toLower(ticket.date + " " + ticket.time), "DD/MM/YYYY h:mm:ss a");
      const daysDiff:number = moment().diff(date, 'days');
      const search = _.toLower(searchValue);
      const searchData = _.toLower(`${(ticket.defect_id || '')}${(ticket.notification_description || '')}${(ticket.status || '')}${(ticket.functional_location || '')}${(ticket.priority || '')}${(ticket.date || '')}${(ticket.time || '')}`);
      const exists =  searchData.search(search);
      if(!search || (search && exists !== -1)){
        if(daysDiff <=1){
          recentTicket.push(ticket);
        }
        if(ticket.status === "DRAFT") {
          unsubmittedTicket.push(ticket);
        }
      }
    })
    setUnsubmitted(unsubmittedTicket)
    setRecent(recentTicket);
    setLoading(false);

  }, [props.notifications.length, searchValue])

  const nodata = (
    <div className={noData}>
      <Icon iconName="sad" />
      <h3>No Data</h3>
    </div>
  );

  const screenHeight = window.innerHeight - 60
  return (
    <section className="ms-Grid">
      <div className="ms-Grid-row">
        <div className="ms-Grid-col ms-xl11 ms-xxl11 ms-xxxl11" style={{height: screenHeight}}>
        <div className={[maximizedPanel, anim].join(" ")}>
  
      <div className={panelHeaderContainer}>
        { !showSearch ? <h3>Ticket summary</h3> : false}
        {/* { !showSearch ? : false} */}
         { showSearch ? <div className={searchBox}><SearchBox
            placeholder="Enter Search Phrase"
            value = {searchValue}
            onChange={(e, searchWord:string |undefined) => setSearchValue((searchWord || ""))}
            disableAnimation
            className={searchBox}
            onClear={() => {
              setSearchValue('')
              setShowSearch(false)
            }}
            // onSearch = {searchValue => setSearchValue(searchValue)}
            onEscape={() => {
              setSearchValue('')
              setShowSearch(false)
            }}
        />
        {/* <Icon iconName="cancel" className={cancelIcon} onClick={() => { */}
              {/* setSearchValue('') */}
        {/* }}/> */}
        </div>: false}
        
        { !showSearch ? <div className={panelHeaderContainer}>
          <SearchIcon className={searchIcon} onClick = {() => setShowSearch(true)}/>
          <RoundButton text="Show All" />
          </div> : false}
      </div>
      <div className={cardsParent}>
      <Pivot 
        className={linkIsSelected}
      >
        <PivotItem
          headerText={`Unsubmitted(${_.size(unsubmitted)})`}
        >
          {
            !props.fetching && !loading ? (
            <FocusZone direction={FocusZoneDirection.vertical} className={focusZone}>
              { _.size(unsubmitted) === 0
                ? nodata
                : <List className={selected} items={unsubmitted} onRenderCell={onRenderCell} />
              }
            </FocusZone>
            ): <Spinner size={SpinnerSize.large}/>
          }

        </PivotItem>
      <PivotItem 
        headerText={`Recent(${_.size(recent)})`}
      >
        {
          !props.fetching &&!loading ? (
            <FocusZone direction={FocusZoneDirection.vertical} className={focusZone}>
              { _.size(recent) === 0
                ? nodata
                : <List className={selected} items={recent} onRenderCell={onRenderCell} />
              }
            </FocusZone> 
          ): <Spinner size={SpinnerSize.large}/>
        }
      </PivotItem>
    </Pivot>
      </div>
    </div>
        </div>
        <div className="ms-Grid-col ms-xl1 ms-xxl1 ms-xxxl1 leftArrow" style={{height: screenHeight}}>
        <UpArrow className={[leftArrowClose, arrowRotation].join(" ")} onClick={animHandler} />
          </div>
      </div>
    
    </section>
  );
};


// Connecting To Redux ----------------------------------------------------------------------
function mapStateToProps(state: any): any {
  return {
    notifications: state.serviceNotificationReducer.notifications,
    selectedTicket: state.serviceNotificationReducer.selectedTicket,
    notificationsValues: state.serviceNotificationReducer.notificationsValues,
    fetching: state.serviceNotificationReducer.loading
  };
}

function mapDispatchToProps(dispatch: Dispatch<any>): any {
  return {
    ...bindActionCreators(
      {
        fetchServiceNotifications,
        setSelectedTicket
      },
      dispatch,
    ),
  };
}

const MaximizedPanelComponent = connect(mapStateToProps, mapDispatchToProps)(MaximizedPanel);


export default MaximizedPanelComponent;