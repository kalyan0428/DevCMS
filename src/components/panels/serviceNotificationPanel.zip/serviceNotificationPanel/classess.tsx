import {
  mergeStyleSets,
  AnimationStyles,
  // AnimationClassNames,
  //AnimationVariables,
} from "@fluentui/react/lib/Styling";

export const panelCards: any = {
  panelHeaderContainer: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "0px 5px",
    h3: {
      fontFamily: "roboto-reg",
    },
  },
  searchIcon: {
    width: "24px",
    height: "24px",
    marginRight: "10px",
    cursor: "pointer",
  },
  cardsParent: {
    overflow: "auto",
    marginTop: "20px",
  },
  card: {
    backgroundColor: "#2E2E33",
    marginBottom: "10px",
    boxSizing: "border-box",
    padding: "10px",
    borderRadius: "3px",
    cursor: "pointer",
    selectors: {
      "&:hover": {
        backgroundColor: "#333D3D",
      },
    },
    ul: {
      display: "flex",
      selectors: {
        "& ul:last-child": {
          fontSize: "12px",
        },
      },
      li: {
        listStyle: "none",
        textAlign: "right",
        selectors: {
          "& li:first-child": {
            paddingRight: "10px",
            position: "relative",
            ":after": {
              content: "'|'",
              position: "absolute",
              top: 0,
              right: "4px",
              bottom: 0,
              margin: "auto",
              color: "#666",
            },
          },
        },
      },
    },
  },
  selectedCard: {
    backgroundColor: "#333D3D"
  },
  cardHeaderContainer: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },
  cardBody: {
    padding: "20px 0",
  },
  cardBottom: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    div: {
      display: "flex",
      alignItems: "center",
    },
  },
  labelWidth: {
    maxWidth: "70px",
  },
  labelWidth2: {
    maxWidth: "140px",
  },
  service_data_class: {
    border: "1px solid grey ",
  },
  ticketDetails: {
    border: "1px solid grey",
    borderRadius: "5px"
  },
  bottomLinks: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
  },
  ticketDetailsName: {
    padding: "5px",
    fontWeight: "600",
    backgroundColor: "rgb(46, 46, 51) !important"
  },
  notificationcontainer: {
  },
  grid_cell: {
    padding: "5px !important",
  },
  subText: {
    marginTop: "5px"
  },
  LongText: {
    marginTop: "20px",
  },
  service_links: {
    color: "teal",
    marginLeft: "10px",
    marginTop: "30px",
  },
  link: {
    color: "teal",
    textDecoration: "underline",
    margin: "5px",
    fontWeight: "600",
    pointer: "cursor"
  },
  service_links_first: {
    color: "teal",
    marginTop: "30px",
  },
  bottomLinks2: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between"
  },
  description_body: {
    backgroundColor: "#26262d !important",
  },
  filled_button: {
    border: "1px solid #008B98",
    boxSizing: "border-box",
    lineHeight: " 16px",
    borderRadius: " 50px",
    color: "white",
    whiteSpace: "nowrap",
    backgroundColor: "darkcyan",
    // padding: "5px",
    width: "80px",
    height: "32px",
    // marginLeft: "5px"
  },
  service_column_class: {
    borderRight: "1px solid gray",
    padding: "10px !importatn"
  },

  grid_row: {
    margin: "0px !important"
  },
  DescrptionParent: {
    overflowY: "scroll"
  },
  DescriptionHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    borderBottom: "solid gray 1px",
    borderTop: "solid gray 1px",
    padding: "12px",
    backgroundColor: "#2E2E33 !important"
  },
  DescriptionHeaderEdit: {
    display: "flex",
    alignItems: "center",
    borderBottom: "solid gray 1px",
    borderTop: "solid gray 1px",
    padding: "12px",
    backgroundColor: "#2E2E33 !important"
  },
  headerTitle: {
    marginRight: "90px",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",

  },
  headerSubTitle: {
    display: "flex",
    alignItems: "center",
    fontSize: "11px",
    marginTop: "8px"
  }
};

export const classNames: any = mergeStyleSets(
  {
    linkIsSelected: {
      ".ms-Pivot-link": {
        padding: 0,
        margin: "0 5px",
        fontSize: "14px",
        fontWeight: "600",
        selectors: {
          "& .ms-Pivot-link:hover": {
            background: "transparent",
            color: "#008B98",
          },
        },
      },
      ".is-selected": {
        color: "#008B98",
      }
    },
    deletePopUpContainer: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      flexDirection: "column",
      color: "white",
      height: "175px"
    },
    renderTextPopUpStyle: {
      // margin: "10px",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      flexDirection: "column",
      color: "white",
      padding: "10px"
    },
    deleteButtons: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-around",
    },
    buttonContainer: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      backgroundColor: "#2E2E33 !important",
      height: "78px",
      paddingLeft: "10px",
      paddingRight: "10px"
    },
    minimizedPanel: {
      // width: "50%",
      height: "100%",
      paddingTop: "80px",
      backgroundColor: "#333D3D;",
      // position: "fixed",
      // top: "60px",
      // left: "50px",
      // bottom: 0,
      // zIndex: "997",
      borderTop: "1px solid #666",
      textAlign: "center",
    },
    borderRigth: {
      borderRight: "solid gray 1px"
    },
    textRotation: {
      transform: "rotate(-90deg)",
      color: "#F5F5F5",
      whiteSpace: "nowrap",
      marginTop: "90px",
    },
    attachment: {
      minWidth: "80px",
      maxWidth: "80px",
      minHeight: "80px",
      maxHeight: "80px"
    },
    focusZone: {
      padding: '10px'
    },
    countRotation: {
      transform: "rotate(-90deg)",
    },
    noData: {
      textAlign: "center",
      fontSize: "22px",
      color: "#008B98",
      paddingTop: "20px",
      h3: {
        fontSize: "18px",
        fontWeight: "normal",
      },
    },
    arrowRotation: {
      transform: "rotate(-270deg)",
    },
    arrowRotation90: {
      transform: "rotate(-90deg)",
    },
    searchBox: {
      width: "100%",
      ".ms-SearchBox-icon": {
        transform: "rotate(270deg)"
      }
    },
    cancelIcon: {
      position: "absolute",
      right: "22px",
      top: "28px"
    },
    textContainer: {
      marginTop: "30px",
      position: "relative",
      span: {
        position: "absolute",
        top: "4px",
        right: 0,
        left: 0,
        bottom: 0,
        margin: "auto",
      },
    },
    leftArrow: {
      cursor: "pointer",
      position: "absolute",
      top: "30px",
      right: "-20px",
      bottom: 0,
    },
    maximizedPanel: {
      // width: "300px",
      height: "100%",
      backgroundColor: "#26262D",
      // position: "fixed",
      // top: "60px",
      // left: "50px",
      // bottom: 0,
      // zIndex: "998",
      borderTop: "1px solid #666",
      padding: "20px 10px",
      boxSizing: "border-box",
    },
    actions: {  
      backgroundColor: "rgb(20, 20, 20)"
    },
    actionsRow: {
      marginTop: "10px !important",
      marginBottom: "10px !important"
    },
    deleteButton: {
      backgroundColor: "rgb(20, 20, 20)"
    },
    leftArrowClose: {
      cursor: "pointer",
    },

    maximizedPanelOpen: {
      ...AnimationStyles.slideRightIn400,
    },
    maximizedPanelClose: {
      ...AnimationStyles.slideLeftOut400,
    },
  },
  panelCards
);